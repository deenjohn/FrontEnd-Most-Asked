No lecture, just code-along in the exercise.
