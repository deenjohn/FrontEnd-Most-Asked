# No exercise

You've worked hard for two days, just sit back and enjoy the the rest of the presentation.
