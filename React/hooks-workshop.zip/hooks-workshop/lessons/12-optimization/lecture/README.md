- useMemo on calculateWeeks
- memo
- useCallback

- useMemo on calculateWeeks.js
  - console.time it
  - console.log when it memos
- Go to the feed
- Show how the profiler works
- React.memo on FeedPost and show how it saves on renders
- show that post={post} is new each time, causing
  - spread the props instead, fixed (but ehhhhh)
- Go to the calendar
  - make it huge (don't forget the CSS for the height)
  - start memoing everything
  - useCallback (just a useMemo shortcut for functions)

