No lecture, just the exercise.
