1. Start with `SignupForm.js` (explain useReducer)
2. Then open `useAuth.js` (explain app state)

All other files are referenced in the explanation of app state
