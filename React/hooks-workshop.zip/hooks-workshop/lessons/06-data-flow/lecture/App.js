/******************************************************************************/
// open NewPost.js
import React, { useState, useEffect } from 'react'

import App from '../../../modules/app/App'
export default App
